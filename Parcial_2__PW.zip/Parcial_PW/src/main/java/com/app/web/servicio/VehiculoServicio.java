package com.app.web.servicio;

import java.util.List;
import com.app.web.entidad.vehiculo;

public interface VehiculoServicio {

	public List<vehiculo> listarTodosLosVehiculos();
}
