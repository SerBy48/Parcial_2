package com.app.web.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.web.entidad.vehiculo;

@Repository
public interface VehiculoRepositorio extends JpaRepository<vehiculo, Long>{

}
