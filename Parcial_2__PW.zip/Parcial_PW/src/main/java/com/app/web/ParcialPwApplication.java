package com.app.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParcialPwApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParcialPwApplication.class, args);
	}

}
