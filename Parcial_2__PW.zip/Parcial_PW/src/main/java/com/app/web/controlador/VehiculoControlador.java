package com.app.web.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.app.web.servicio.VehiculoServicio;

	@Controller
	public class VehiculoControlador {
		
		@Autowired 
		private VehiculoServicio servicio;
		
		@GetMapping({"/vehiculo","/"})
		public String ListarVehiculos(Model modelo) {
			modelo.addAttribute("vehiculo", servicio.listarTodosLosVehiculos() );
			return "vehiculo";
		}

}
